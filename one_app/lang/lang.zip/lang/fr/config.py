
translate = {
 'ai': {'translation': 'e', 'word': 'éclair', 'sound':'sound/franc/ai.mp3'},
 'au': {'translation': 'o', 'word': 'auteur', 'sound':''},
 'ou': {'translation': 'u', 'word': 'boutique', 'sound':''},
 'oi': {'translation': 'ła', 'word': 'anchois', 'sound':''},
 'gn': {'translation': 'ń', 'word': 'montagne', 'sound':''},
 'ch': {'translation': 'sz', 'word': 'chambre', 'sound':''},
 'ç': {'translation': 's', 'word': 'garçon', 'sound':''},
 'j': {'translation': 'ż', 'word': 'jeune', 'sound':''},
 'œ ': {'translation': 'e/y', 'word': 'sœur', 'sound':''},
 'ph': {'translation': 'f', 'word': 'phase', 'sound':''},
 'on': {'translation': 'ą', 'word': 'déclinaison', 'sound':''},
 'om': {'translation': 'ą', 'word': 'ombre', 'sound':''},
 'an': {'translation': 'ą', 'word': 'ange', 'sound':''},
 'am': {'translation': 'ą', 'word': 'ambiance', 'sound':''},
 'in': {'translation': 'ę', 'word': 'merlin', 'sound':''},
 'im': {'translation': 'ę', 'word': 'limbe', 'sound':''},
 }
